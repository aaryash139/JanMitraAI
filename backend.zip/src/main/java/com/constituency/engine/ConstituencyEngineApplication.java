package com.constituency.engine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConstituencyEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConstituencyEngineApplication.class, args);
	}

}
